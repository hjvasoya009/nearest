<?php 

echo "Content goes here...";
?>
